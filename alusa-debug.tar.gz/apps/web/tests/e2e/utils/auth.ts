import { expect, Page } from '@playwright/test';

// Helper de login centralizado para os testes E2E.
// Usa o usuário seed criado em tests/e2e-global-setup.ts
export async function login(page: Page, email = 'aluno@example.com', password = 'senha123') {
  // Ir para a nova rota de login no segmento (auth)
  await page.goto('/login');
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Senha').fill(password);
  await page.getByRole('button', { name: /Entrar/i }).click();

  // Esperar navegação /portal e header visível
  await page.waitForURL('**/portal', { timeout: 10000 });
  await expect(page.getByText('Portal do Aluno')).toBeVisible({ timeout: 10000 });
}
