import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { PerfilUsuario } from '@prisma/client';

const publicPaths = ['/login'];

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (publicPaths.includes(pathname) || pathname.startsWith('/api/auth')) {
    return NextResponse.next();
  }
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token) return NextResponse.redirect(new URL('/(auth)/login', req.url));
  const perfil = (token as unknown as { perfil?: PerfilUsuario }).perfil;
  if (pathname.startsWith('/portal') && !perfil) {
    return NextResponse.redirect(new URL('/(auth)/login', req.url));
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)']
};
