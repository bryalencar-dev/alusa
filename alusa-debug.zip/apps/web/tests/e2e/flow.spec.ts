import { test, expect } from '@playwright/test';
import { login } from './utils/auth';
import { createInvite, acceptInvite, createMatricula, simulateWebhookAsaas, markPresenca, createEventoComprarIngresso, checkinQR } from './utils/flow-helpers';

// Fluxo ponta a ponta MVP (Etapa 24)
// NOTA: Diversos helpers ainda são placeholders até que endpoints/UI sejam implementados.

const ADMIN_EMAIL = 'aluno@example.com'; // usando usuário seed atual como "admin" placeholder
const NOVO_USUARIO_EMAIL = 'novo.usuario+e2e@example.com';
const NOVO_USUARIO_SENHA = 'SenhaForte!123';

let conviteLink: string; let matriculaId: string; let eventoCtx: { eventoId: string; ingressoId: string; qr: string };

test.describe.serial('Fluxo E2E Completo', () => {
  let adminPage: import('@playwright/test').Page;
  test.beforeAll(async ({ browser }) => {
    const ctx = await browser.newContext();
    adminPage = await ctx.newPage();
    await login(adminPage, ADMIN_EMAIL, 'senha123');
  });

  test('1. Admin cria convite', async () => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const r = await createInvite(adminPage, NOVO_USUARIO_EMAIL);
  conviteLink = r.link;
    expect(conviteLink).toContain('convite');
  });

  test('2. Usuário aceita convite e cria senha', async ({ page }) => {
    await acceptInvite(page, conviteLink, NOVO_USUARIO_SENHA);
    // Futuro: validar mensagem de sucesso / redirecionamento
  });

  test('3. Login com credenciais criadas', async ({ page }) => {
    await login(page, NOVO_USUARIO_EMAIL, NOVO_USUARIO_SENHA);
    await expect(page.getByText('Portal do Aluno')).toBeVisible();
  });

  test('4. Criação de matrícula com taxa, desconto e combo', async ({ page }) => {
    const m = await createMatricula(page, { alunoEmail: NOVO_USUARIO_EMAIL, planoNome: 'Plano E2E', taxa: 50, desconto: 10, combo: 'Combo E2E' });
    matriculaId = m.id;
    expect(matriculaId).toBeTruthy();
  });

  test('5. Simula webhook Asaas e confirma pagamento', async ({ page }) => {
    await simulateWebhookAsaas(page, 'cobranca-mock-id');
    // Futuro: validar UI de cobrança paga
  });

  test('6. Professor marca presença', async ({ page }) => {
    await markPresenca(page, matriculaId, 'PRESENTE');
    // Futuro: validar presença listada
  });

  test('7. Evento + compra de ingresso + QR check-in', async ({ page }) => {
    eventoCtx = await createEventoComprarIngresso(page, NOVO_USUARIO_EMAIL);
    await checkinQR(page, eventoCtx.qr);
    expect(eventoCtx.qr).toContain('QR-');
  });

  test('8. Portal do aluno/responsável exibe dados', async ({ page }) => {
    await login(page, NOVO_USUARIO_EMAIL, NOVO_USUARIO_SENHA);
    // Visitar páginas
    await page.goto('/portal/matriculas');
    await expect(page.getByRole('heading', { name: /Minhas Matrículas/i })).toBeVisible();
    await page.goto('/portal/eventos');
    await expect(page.getByRole('heading', { name: /Eventos/i })).toBeVisible();
    await page.goto('/portal/cobrancas');
    await expect(page.getByRole('heading', { name: /Cobranças/i })).toBeVisible();
  });
});
